package com.greenorange.myuiaccount;

/**
 * Created by JasWorkSpace on 15/10/30.
 */
public class Feature {
    public final static boolean isSecureUserData(){
        return true;
    }
    public final static boolean isOnlyOneAccount(){
        return true;
    }
}
