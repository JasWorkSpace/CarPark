package com.greenorange.myuiaccount.UI;

import android.app.Activity;
import com.loopj.android.http.AsyncHttpClient;

/**
 * Created by JasWorkSpace on 15/11/2.
 */
public class BaseActivity extends Activity {
    public AsyncHttpClient asyncHttpClient = new AsyncHttpClient();




}
