package com.greenorange.myuiaccount.UI;

import android.content.Context;
import android.view.View;
import android.view.animation.AnimationUtils;

import com.greenorange.myuiaccount.R;

/**
 * Created by JasWorkSpace on 15/10/15.
 */
public class AnimationHelper {


}
