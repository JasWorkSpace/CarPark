package com.greenorange.myuiaccount;


/**
 * Created by JasWorkSpace on 15/10/20.
 */
public class Config {

    public final static String SHAREDPREFERENCES_FILE_NAME = "SHAREDPREFERENCES_FILE_NAME";
}
